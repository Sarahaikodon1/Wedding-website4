import React from 'react';
import WeddingWebsite from './WeddingWebsite';

function App() {
  return <WeddingWebsite />;
}

export default App;
